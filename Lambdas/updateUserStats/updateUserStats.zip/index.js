const AWS = require('aws-sdk');
const uuid = require('uuid');
const moment = require('moment');

AWS.config.update({ region: 'us-east-1' });
var ddb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

async function uploadData(body) {
    try {
        let word = await readItem();
        var params = {
            TableName: 'woc_user_stats',
            Item: {
                'id': { S: `${uuid.v4()}` },
                'word': { S: `${word}` },
                'userId': { S: `${body.userId}` },
                'startTime': { S: `${body.startTime}` },
                'endTime': { S: `${body.endTime}` },
                'numberOfAttempts': { N: `${body.numberOfAttempts}` },
                'created_at': { S: `${moment(new Date()).utc().valueOf()}` }
            }
        };

        await ddb.putItem(params, function (err, data) {
            if (err) {
                console.log("Error", err);
            } else {
                console.log("Success", data);
            }
        }).promise();
    }
    catch (e) {
        console.log("Error : ", e);
    }
}

async function readItem() {
    try {
        let ExpressionAttributeValues = {};
        let FilterExpression = "";

        FilterExpression = "typeOfWord = :typeOfWord";
        ExpressionAttributeValues = {
            ':typeOfWord': { S: "default" }
        };
        var params = {
            FilterExpression,
            ExpressionAttributeValues,
            ProjectionExpression: 'word',
            TableName: 'woc_word'
        };

        return new Promise((resolve, reject) => {
            ddb.scan(params, function (err, data) {
                if (err) {
                    console.log("Error", err);
                    reject("");
                } else {
                    console.log(data.Items[0].word.S);
                    resolve(data.Items[0].word.S);
                }
            });
        });
    } catch (e) {
        console.log("Error : ", e);
    }
}



exports.handler = async (event) => {

    let body = JSON.parse(event?.body);

    // body = {
    //     userId:"sarthak",
    //     numberOfAttempts:4,
    //     startTime:new Date(),
    //     endTime:new Date()
    // }

    await uploadData(body);

    const response = {
        statusCode: 200,
        body: "",
    };
    return response;
};

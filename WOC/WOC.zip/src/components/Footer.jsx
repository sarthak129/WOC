export default function Footer() {
  return (
    <div className="flex flex-wrap items-center justify-center px-2 py-3 bg-cyan-600">
      <p className="text-xl font-pacifico font-bold text-white">
        built by Group 25
      </p>
    </div>
  );
}
